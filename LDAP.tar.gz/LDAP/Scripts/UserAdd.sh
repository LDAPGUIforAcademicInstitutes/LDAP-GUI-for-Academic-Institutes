#!/bin/bash

# LDAP GUI for Academic Institutes
# Graphical User Interface for installing and configuring LDAP Service for Academic Institutes

# Developed at : Department of Computer Engineering and Information Technology, College of Engineering, Pune, Maharashtra, India. November 2010

# File Description : 
        # This file creates the ldif files for the users and adds them to the LDAP server. 

        # Wherever possible, we have included comments so that it becomes easier for the user/administrator to understand what exactly is going on whilst installation.

        # Other details about references, and other approaches to installation are presented in Chapter 7 of our report. 

        # Command Line Parameters to this file: 
        	# None
	# Output : 
                # ldif files of all the users whose accounts are requested.


# Set the start of Uid
# --------------------------------

uidc=17002


# E.g. This loop iterates from the 2 to 100, i.e. students with roll nos. 2 to 100 will have their LDAP accounts once this script is executed successfully.
for j in {2..100} 
do
        a="/comp/students/"
	echo "dn: cn=$j,ou=students,ou=comp,dc=coep,dc=com" > $j
	echo "uid: $j" >> $j  
	echo "cn: $j" >> $j
	echo "objectClass: account" >> $j
	echo "objectClass: posixAccount" >> $j
	echo "objectClass: top" >> $j
	echo "objectClass: shadowAccount" >> $j
	echo "userpassword: test" >>  $j
	echo "shadowLastChange: 2000" >> $j
	echo "shadowMax: 99999" >> $j
	echo "shadowWarning: 7" >> $j
	echo "loginShell: /bin/bash" >> $j
	echo "uidNumber: $uidc" >> $j
	echo "gidNumber: 14001" >> $j
	echo "homeDirectory: /comp/students/$j" >> $j
	echo "gecos: $j,2011c,students,comp" >> $j
 ldapadd -f $j -x -D "cn=Manager,dc=coep,dc=com" -w secret
	mkdir -p $a/$j
	chown $j $a/$j

	uidc=`expr $uidc + 1`
done
